# *AutoVariate: A Python Package to build Variational Autoencoders* 

AutoVariate is a python module to make the usage of Variational Autoencoders more streamlined

Link to package: https://pypi.org/project/autovariate/1.0.2/

Installing AutoVariate

```
pip3 install autovariate
```

Documentation can be found here:

(Insert Link Once I make the docs)



